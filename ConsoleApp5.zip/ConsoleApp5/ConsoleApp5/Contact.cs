﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    /**
     * Would act as a model
     */
    internal class Contact
    {
        public long Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Company { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }

        public Contact() { }

        public override string? ToString()
        {
            return $"Förnamn: {FirstName}\n" +
                $"Efternamn: {LastName}\n" +
                $"Företag: {Company}\n" +
                $"Telefonnummer: {Phone}\n" +
                $"E-post: {Email}\n";
        }
    }
}
