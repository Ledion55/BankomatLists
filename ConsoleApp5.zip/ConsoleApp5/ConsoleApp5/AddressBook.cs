﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    /**
     * Would act as a controller
     */
    internal class AddressBook
    {
        private Menu menu;

        public AddressBook()
        { 
            menu = new Menu(this);
        }

        // Skapat upp contexten som en class-property
        ContactsDbContext dbCtx = new ContactsDbContext();
        // Skapa upp ett meny-objekt som en class-property

        // En start metod som presenterar huvudmeny

        // Metod som hanterar input från huvudmeny

        public void HandleNewCustomerMenu(string firstName, string lastName, string company, string phone, string email)
        {
            dbCtx.Add(new Contact()
            {
                FirstName = firstName,
                LastName = lastName,
                Company = company,
                Email = email,
                Phone = phone
            });
            dbCtx.SaveChanges();
        }

        // Metod som hanterar input från ändra-kontakt meny

    }
}
