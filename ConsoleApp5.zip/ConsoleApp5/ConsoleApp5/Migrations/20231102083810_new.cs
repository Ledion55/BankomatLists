﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ConsoleApp5.Migrations
{
    /// <inheritdoc />
    public partial class @new : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Address",
                table: "Contacts");

            migrationBuilder.DropColumn(
                name: "City",
                table: "Contacts");

            migrationBuilder.RenameColumn(
                name: "Region",
                table: "Contacts",
                newName: "LastName");

            migrationBuilder.RenameColumn(
                name: "PostalCode",
                table: "Contacts",
                newName: "FirstName");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Contacts",
                newName: "Company");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "LastName",
                table: "Contacts",
                newName: "Region");

            migrationBuilder.RenameColumn(
                name: "FirstName",
                table: "Contacts",
                newName: "PostalCode");

            migrationBuilder.RenameColumn(
                name: "Company",
                table: "Contacts",
                newName: "Name");

            migrationBuilder.AddColumn<string>(
                name: "Address",
                table: "Contacts",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "City",
                table: "Contacts",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
