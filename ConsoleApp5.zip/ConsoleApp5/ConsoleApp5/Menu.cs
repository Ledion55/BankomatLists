﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    /**
     * Would act as a view
     */
    internal class Menu
    {
        private AddressBook addressBook;

        public Menu(AddressBook addressbook)
        {
            this.addressBook = addressbook;
        }

        // Metod för att visa huvudmeny

        // Metod för att visa skapa-kontakt
        public void CreateContact()
        {
            Console.WriteLine("Ange Förnamn");
            string firstName = Console.ReadLine();
            Console.WriteLine("Ange Efternamn");
            string lastName = Console.ReadLine();
            Console.WriteLine("Ange Företag");
            string company = Console.ReadLine();
            Console.WriteLine("Ange Telefonnummer");
            string phone = Console.ReadLine();
            Console.WriteLine("Ange Email");
            string email = Console.ReadLine();

            addressBook.HandleNewCustomerMenu(firstName, lastName, company, phone, email);

        }

        // Metod för att visa ändra-kontakt

        // Metod för att lista alla kontakter

    }
}
